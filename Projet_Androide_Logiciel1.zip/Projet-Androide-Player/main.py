from .Players.PlayerBasic import PlayerBasic

def generateData():
    basicPlayer = PlayerBasic()
    


generateData()


    